"""
GUI 模块 — 弹出翻译结果窗口
使用 tkinter（Python 自带，无需安装）
"""

import tkinter as tk
from tkinter import ttk


def show_translation_popup(original_text: str, translated_text: str):
    """
    弹出一个置顶小窗口，显示原文和译文。

    特点：
    - 窗口始终置顶
    - 出现在鼠标位置附近
    - 点窗口外部或按 Esc 自动关闭
    - 有"复制译文"按钮
    """

    # ========== 创建窗口 ==========
    root = tk.Tk()
    root.title("翻译结果")
    root.resizable(True, True)  # 允许用户自由调整大小

    # 配色方案
    BG_COLOR = "#ffffff"        # 白色背景
    FG_COLOR = "#1a1a1a"        # 深色文字
    SUB_COLOR = "#666666"       # 灰色次要文字
    ACCENT_COLOR = "#4a90d9"    # 蓝色强调
    BORDER_COLOR = "#e0e0e0"    # 边框色

    root.configure(bg=BG_COLOR)

    # ========== 窗口位置：鼠标附近 ==========
    window_width = 520
    window_height = 280
    x = root.winfo_pointerx() + 20
    y = root.winfo_pointery() + 20

    # 防止窗口超出屏幕
    screen_width = root.winfo_screenwidth()
    screen_height = root.winfo_screenheight()
    if x + window_width > screen_width:
        x = screen_width - window_width - 20
    if y + window_height > screen_height:
        y = screen_height - window_height - 20
    if x < 0:
        x = 20
    if y < 0:
        y = 20

    root.geometry(f"{window_width}x{window_height}+{x}+{y}")

    # ========== 窗口置顶 ==========
    root.attributes("-topmost", True)

    # ========== 关闭逻辑 ==========
    def close_window(event=None):
        """关闭窗口"""
        root.destroy()

    root.bind("<Escape>", close_window)  # 按 Esc 关闭

    # 窗口失去焦点时自动关闭
    def on_focus_out(event=None):
        # 延迟检查，避免误触发
        root.after(200, lambda: root.destroy() if not root.focus_get() else None)

    root.bind("<FocusOut>", on_focus_out)

    # ========== 主框架 ==========
    main_frame = tk.Frame(root, bg=BG_COLOR, padx=20, pady=15)
    main_frame.pack(fill=tk.BOTH, expand=True)

    # ========== 标题栏 ==========
    title_bar = tk.Frame(main_frame, bg=BG_COLOR)
    title_bar.pack(fill=tk.X, pady=(0, 10))

    title_label = tk.Label(
        title_bar,
        text="🔤 翻译结果",
        font=("Microsoft YaHei UI", 11, "bold"),
        fg=ACCENT_COLOR,
        bg=BG_COLOR,
    )
    title_label.pack(side=tk.LEFT)

    # 关闭按钮
    close_btn = tk.Label(
        title_bar,
        text="✕",
        font=("Microsoft YaHei UI", 14),
        fg=SUB_COLOR,
        bg=BG_COLOR,
        cursor="hand2",
    )
    close_btn.pack(side=tk.RIGHT)
    close_btn.bind("<Button-1>", close_window)

    # ========== 分隔线 ==========
    separator = tk.Frame(main_frame, height=1, bg=BORDER_COLOR)
    separator.pack(fill=tk.X, pady=(0, 10))

    # ========== 原文区域 ==========
    original_label = tk.Label(
        main_frame,
        text="原文",
        font=("Microsoft YaHei UI", 9),
        fg=SUB_COLOR,
        bg=BG_COLOR,
        anchor="w",
    )
    original_label.pack(fill=tk.X)

    # 原文文本框（可滚动）
    original_frame = tk.Frame(main_frame, bg=BG_COLOR)
    original_frame.pack(fill=tk.X, pady=(2, 10))

    original_text_widget = tk.Text(
        original_frame,
        font=("Microsoft YaHei UI", 10),
        fg=SUB_COLOR,
        bg="#f7f7f7",
        wrap=tk.WORD,
        height=3,
        borderwidth=1,
        relief="solid",
        padx=10,
        pady=8,
    )
    original_text_widget.insert("1.0", original_text)
    original_text_widget.config(state=tk.DISABLED)  # 只读

    # 原文滚动条
    original_scrollbar = ttk.Scrollbar(original_frame, command=original_text_widget.yview)
    original_text_widget.config(yscrollcommand=original_scrollbar.set)
    original_text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    original_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ========== 译文区域 ==========
    translated_label = tk.Label(
        main_frame,
        text="译文",
        font=("Microsoft YaHei UI", 9),
        fg=SUB_COLOR,
        bg=BG_COLOR,
        anchor="w",
    )
    translated_label.pack(fill=tk.X)

    # 译文字文本框（可滚动）
    translated_frame = tk.Frame(main_frame, bg=BG_COLOR)
    translated_frame.pack(fill=tk.BOTH, expand=True, pady=(2, 5))

    translated_text_widget = tk.Text(
        translated_frame,
        font=("Microsoft YaHei UI", 11),
        fg=FG_COLOR,
        bg="#f7f7f7",
        wrap=tk.WORD,
        height=4,
        borderwidth=1,
        relief="solid",
        padx=10,
        pady=8,
    )
    translated_text_widget.insert("1.0", translated_text)
    translated_text_widget.config(state=tk.DISABLED)  # 只读

    # 译文滚动条
    translated_scrollbar = ttk.Scrollbar(translated_frame, command=translated_text_widget.yview)
    translated_text_widget.config(yscrollcommand=translated_scrollbar.set)
    translated_text_widget.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
    translated_scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

    # ========== 按钮栏 ==========
    button_bar = tk.Frame(main_frame, bg=BG_COLOR)
    button_bar.pack(fill=tk.X, pady=(10, 0))

    # 复制按钮的回调
    def copy_translation():
        """复制译文到剪贴板"""
        root.clipboard_clear()
        root.clipboard_append(translated_text)
        # 显示"已复制"提示
        copy_btn.config(text="✅ 已复制！")
        root.after(1500, lambda: copy_btn.config(text="📋 复制译文"))

    copy_btn = tk.Label(
        button_bar,
        text="📋 复制译文",
        font=("Microsoft YaHei UI", 10),
        fg="#ffffff",
        bg=ACCENT_COLOR,
        padx=14,
        pady=5,
        cursor="hand2",
    )
    copy_btn.pack(side=tk.LEFT)
    copy_btn.bind("<Button-1>", lambda e: copy_translation())

    # 关闭按钮
    done_btn = tk.Label(
        button_bar,
        text="关闭",
        font=("Microsoft YaHei UI", 10),
        fg=SUB_COLOR,
        bg="#f0f0f0",
        padx=14,
        pady=5,
        cursor="hand2",
    )
    done_btn.pack(side=tk.RIGHT)
    done_btn.bind("<Button-1>", close_window)

    # ========== 启动主循环 ==========
    root.mainloop()


# 测试代码 —— 直接运行这个文件时会执行
if __name__ == "__main__":
    show_translation_popup(
        original_text="Hello, this is a test sentence for the translation popup window.",
        translated_text="你好，这是一个用于翻译弹出窗口的测试句子。",
    )
