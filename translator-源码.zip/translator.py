"""
翻译模块
方案1: Google 翻译（质量好，1.5 秒超时）
方案2: MyMemory 翻译（兜底，3 秒超时）
"""

import requests


def _is_chinese(text: str) -> bool:
    count = sum(1 for c in text if '一' <= c <= '鿿')
    return count > len(text) * 0.3


def _translate_google(text: str, target_lang: str) -> str:
    """Google 翻译 — 质量最好"""
    url = "https://translate.googleapis.com/translate_a/single"
    resp = requests.get(url, params={
        "client": "gtx",
        "sl": "auto",
        "tl": target_lang,
        "dt": "t",
        "q": text,
    }, timeout=1.5)
    resp.raise_for_status()
    data = resp.json()
    parts = [block[0] for block in data[0] if block[0]]
    return "".join(parts)


def _translate_mymemory(text: str, target_lang: str) -> str:
    """MyMemory 翻译 — 免费兜底"""
    if _is_chinese(text):
        src = "zh-CN"
        dst = target_lang if target_lang != "zh-CN" else "en"
    else:
        src = "en"
        dst = target_lang

    resp = requests.get("https://api.mymemory.translated.net/get", params={
        "q": text,
        "langpair": f"{src}|{dst}",
    }, timeout=3)
    resp.raise_for_status()
    return resp.json()["responseData"]["translatedText"]


def translate(text: str, target_lang: str = "zh-CN") -> str:
    """翻译文本。优先 Google（质量好），失败则用 MyMemory 兜底。"""
    text = text.strip()
    if not text:
        return "（没有内容可以翻译）"

    # 方案1: Google（1.5 秒超时）
    try:
        result = _translate_google(text, target_lang)
        if result.strip():
            return result
    except Exception:
        pass

    # 方案2: MyMemory 兜底
    try:
        result = _translate_mymemory(text, target_lang)
        if result.strip():
            return result
    except Exception as e:
        return f"翻译失败：{e}"

    return "翻译失败，请检查网络。"
