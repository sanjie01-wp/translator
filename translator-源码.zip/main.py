"""
翻译小工具 — 主程序
主线程 = tkinter（弹窗不卡），后台线程 = 托盘 + 热键
"""

import time
import threading
import pyperclip
from pystray import Icon, Menu, MenuItem
from pynput import keyboard
from pynput.keyboard import Key, Controller as KBController
from PIL import Image, ImageDraw, ImageFont

from translator import translate
from gui import show_translation_popup

_kb = KBController()

# ============================================================
# 1. 托盘图标图片
# ============================================================

def _make_icon(size=64):
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    draw.rounded_rectangle([4, 4, size-4, size-4], radius=size//6, fill=(74,144,217,255))
    text, font = "译", None
    for name in ["C:/Windows/Fonts/msyh.ttc","C:/Windows/Fonts/simsun.ttc","C:/Windows/Fonts/msyhbd.ttc"]:
        try: font = ImageFont.truetype(name, size//2+4); break
        except (OSError, IOError): continue
    if not font: text, font = "T", ImageFont.load_default()
    try:
        b = draw.textbbox((0,0), text, font=font); tw, th = b[2]-b[0], b[3]-b[1]
    except AttributeError:
        tw, th = draw.textsize(text, font=font)
    draw.text(((size-tw)//2, (size-th)//2-1), text, fill=(255,255,255,255), font=font)
    return img


# ============================================================
# 2. 托盘图标（后台线程）
# ============================================================

def _run_tray(stop_fn):
    def on_clipboard(icon, item):
        try:
            t = pyperclip.paste()
        except Exception:
            t = ""
        if t.strip():
            show_translation_popup(t, translate(t))
        else:
            show_translation_popup("剪贴板为空", "请先 Ctrl+C 复制文字。")

    def on_about(icon, item):
        show_translation_popup(
            "翻译小工具 v2.0",
            "快捷键: Ctrl + Shift + T\n选中文字后按快捷键即可翻译\n\n翻译引擎: Google + MyMemory"
        )

    def on_quit(icon, item):
        stop_fn()
        icon.stop()

    menu = Menu(
        MenuItem("翻译剪贴板", on_clipboard, default=True),
        MenuItem("关于", on_about),
        Menu.SEPARATOR,
        MenuItem("退出", on_quit),
    )
    icon = Icon("翻译小工具", _make_icon(64), title="翻译小工具 — Ctrl+Shift+T", menu=menu)
    icon.run()


# ============================================================
# 3. 热键 → 翻译 → 弹窗 流程
# ============================================================

_last_trigger = 0


def _on_hotkey(root):
    """
    快捷键触发（在 pynput 线程中调用）。
    用 root.after() 把工作调度到主线程，保证 tkinter 弹窗正常。
    """
    global _last_trigger
    now = time.time()
    if now - _last_trigger < 1.0:
        return
    _last_trigger = now

    # 延迟 100ms 后在主线程执行（等用户松开手）
    root.after(100, _step1_copy, root)


def _step1_copy(root):
    """在主线程：复制选中文字"""
    time.sleep(0.3)  # 确保手指已松开

    # 保存剪贴板
    try:
        old = pyperclip.paste()
    except Exception:
        old = ""

    # 模拟 Ctrl+C
    _kb.press(Key.ctrl)
    _kb.press('c')
    time.sleep(0.05)
    _kb.release('c')
    _kb.release(Key.ctrl)
    time.sleep(0.2)

    # 读取
    try:
        text = pyperclip.paste()
    except Exception:
        text = ""

    # 恢复
    try:
        pyperclip.copy(old)
    except Exception:
        pass

    # 判断
    if not text or not text.strip():
        if old and old.strip():
            text = old
        else:
            show_translation_popup(
                "未获取到文字",
                "请先选中文字，再按 Ctrl+Shift+T\n\n"
                "💡 也可以先 Ctrl+C 复制，\n"
                "再右键托盘图标 → 翻译剪贴板"
            )
            return

    # 在后台线程翻译，完成后回主线程弹窗
    _step2_translate(root, text)


def _step2_translate(root, text):
    """在后台线程翻译，不阻塞主线程"""

    def bg():
        return translate(text)

    def on_done():
        """后台线程完成后，在主线程弹窗"""
        result = result_holder.get("r", "翻译失败")
        show_translation_popup(text, result)

    result_holder = {}

    def runner():
        try:
            result_holder["r"] = bg()
        except Exception as e:
            result_holder["r"] = f"翻译出错: {e}"
        # 调度到主线程弹窗
        root.after(0, on_done)

    t = threading.Thread(target=runner, daemon=True)
    t.start()


# ============================================================
# 4. 热键监听（后台线程）
# ============================================================

def _start_hotkey(root):
    pressed = set()

    def on_press(key):
        pressed.add(key)
        has_ctrl = Key.ctrl_l in pressed or Key.ctrl_r in pressed
        has_shift = Key.shift_l in pressed or Key.shift_r in pressed
        t_keys = {k for k in pressed if hasattr(k, 'char') and k.char and k.char.lower() == 't'}
        other = {k for k in pressed if hasattr(k, 'char') and k.char and k.char.lower() != 't'}
        if has_ctrl and has_shift and t_keys and not other:
            _on_hotkey(root)

    def on_release(key):
        pressed.discard(key)

    listener = keyboard.Listener(on_press=on_press, on_release=on_release)
    listener.start()
    return listener


# ============================================================
# 5. 主入口
# ============================================================

def main():
    print("=" * 50)
    print("  翻译小工具 v2.0")
    print("  Ctrl+Shift+T 翻译选中文字")
    print("=" * 50)

    import tkinter as tk
    root = tk.Tk()
    root.withdraw()  # 隐藏主窗口

    # 启动热键
    listener = _start_hotkey(root)
    print("[OK] 热键已启动")

    # 启动托盘（后台线程）
    threading.Thread(target=_run_tray, args=(listener.stop,), daemon=True).start()
    print("[OK] 托盘已启动")
    print("[OK] 去试试：选中文字 → Ctrl+Shift+T")
    print()

    # 主线程跑 tkinter
    root.mainloop()

    listener.stop()
    print("[OK] 已退出")


if __name__ == "__main__":
    main()
