# 翻译小工具 🈚

一个轻量级 Windows 桌面翻译工具。**选中文字 → 按快捷键 → 弹出翻译。**

![Python](https://img.shields.io/badge/Python-3.8+-blue)
![Platform](https://img.shields.io/badge/Platform-Windows_10%2F11-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)

## ✨ 功能

- 🖱️ **选中即译**：在任意位置选中文字，按 `Ctrl + Shift + T` 弹出翻译
- 📋 **剪贴板翻译**：右键托盘图标，翻译已复制的内容
- 🪟 **窗口置顶**：翻译弹窗始终在最前面，看完即关
- 🌐 **双引擎**：Google 翻译（高质量）+ MyMemory（免费兜底），自动切换
- 📦 **单文件打包**：可打包成单个 `.exe`，发给别人直接运行

## 🚀 快速开始

### 方式一：直接运行（需要 Python）

```bash
# 1. 克隆项目
git clone https://github.com/你的用户名/translator.git
cd translator

# 2. 创建虚拟环境
python -m venv venv
venv\Scripts\activate

# 3. 安装依赖
pip install -r requirements.txt

# 4. 运行
python main.py
```

### 方式二：打包成 exe（无需 Python）

```bash
pip install pyinstaller
pyinstaller --onefile --name "翻译小工具" main.py
# exe 在 dist/ 目录下
```

## 🎮 使用方法

| 操作 | 方式 |
|------|------|
| 翻译选中文字 | 选中文字 → `Ctrl + Shift + T` |
| 翻译剪贴板 | 右键托盘图标 → 翻译剪贴板 |
| 复制翻译结果 | 弹窗中点击「复制译文」 |
| 关闭弹窗 | 按 `Esc` 或点弹窗外任意位置 |
| 退出程序 | 右键托盘图标 → 退出 |

## 📁 项目结构

```
translator/
├── main.py          # 主程序（托盘图标 + 快捷键监听）
├── translator.py    # 翻译模块（Google + MyMemory）
├── gui.py           # 弹窗界面（tkinter）
├── requirements.txt # Python 依赖
├── .gitignore
└── README.md
```

## 🔧 技术栈

- **GUI**: tkinter（Python 内置）
- **托盘图标**: pystray + Pillow
- **全局热键**: pynput
- **翻译 API**: Google Translate + MyMemory

## 📝 License

MIT — 随意使用、修改、分享。
